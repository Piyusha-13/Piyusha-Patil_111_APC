def is_prime(n):
    if n < 2:
        return False

    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False

    return True

def is_palindrome(n):
    n = str(n)
    return n == n[::-1]

def is_armstrong(n):
    digits = str(n)
    power = len(digits)

    total = sum(int(digit) ** power for digit in digits)

    return total == n

def is_perfect(n):
    if n <= 1:
        return False

    total = 0

    for i in range(1, n):
        if n % i == 0:
            total += i

    return total == n