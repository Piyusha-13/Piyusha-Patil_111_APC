def total_marks(marks):
    return sum(marks)


def percentage(marks):
    return total_marks(marks) / len(marks)


def grade(percent):
    if percent >= 90:
        return "A+"
    elif percent >= 80:
        return "A"
    elif percent >= 70:
        return "B"
    elif percent >= 60:
        return "C"
    elif percent >= 50:
        return "D"
    else:
        return "F"