from recursive_utils import factorial, fibonacci, sum_of_digits, binary

n = int(input("Enter a number: "))

print("Factorial:", factorial(n))
print("Sum of digits:", sum_of_digits(n))
print("Binary:", binary(n))

print("Fibonacci series:")
for i in range(n):
    print(fibonacci(i), end=" ")
print()