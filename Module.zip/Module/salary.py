def gross_salary(basic, allowances):
    return basic + allowances


def deductions(gross, deduction_rate):
    return gross * deduction_rate / 100


def net_salary(gross, deduction):
    return gross - deduction