import string_utils

text = input("Enter a string: ")

print("Number of vowels:", string_utils.count_vowels(text))
print("Reversed string:", string_utils.reverse_string(text))
print("Palindrome:", string_utils.is_palindrome(text))
print("Number of words:", string_utils.count_words(text))
print("Without spaces:", string_utils.remove_spaces(text))