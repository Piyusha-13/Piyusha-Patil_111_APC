#Create a Python module calculator.py containing functions for addition, subtraction, multiplication, and division. Create another program that imports the module and performs calculations based on user input.

def add(x, y):
    return x + y
def subtract(x, y):
    return x - y
def multiply(x, y):
    return x * y
def divide(x, y):
    if y != 0:
        return x / y
    else:
        return "Error: Division by zero is not allowed."
