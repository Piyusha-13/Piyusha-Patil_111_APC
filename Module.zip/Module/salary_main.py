import salary

basic = float(input("Enter basic salary: "))
allowances = float(input("Enter allowances: "))
deduction_rate = float(input("Enter deduction percentage: "))

gross = salary.gross_salary(basic, allowances)
deduction = salary.deductions(gross, deduction_rate)
net = salary.net_salary(gross, deduction)

print("\n--- Salary Details ---")
print("Basic Salary:", basic)
print("Allowances:", allowances)
print("Gross Salary:", gross)
print("Deductions:", deduction)
print("Net Salary:", net)