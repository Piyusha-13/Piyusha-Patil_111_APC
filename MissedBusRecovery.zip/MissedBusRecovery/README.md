# Missed Bus Connection Recovery System

A college-level Python mini project that helps a traveller recover from a missed transport connection. It includes a local simulated booking confirmation for a selected option, but uses no database, payment system, live API, or real reservation.

## Objective and problem statement

When a first bus reaches an intermediate city late, the next scheduled connection may already have departed. This application checks whether that connection was missed, finds future direct services in a local CSV file, calculates travel factors, and ranks the alternatives using a transparent academic scoring model.

For example, a traveller reaches Pune at 13:00 for a 12:30 Pune-to-Mumbai connection. The connection is missed; the program searches the sample routes after the current time and presents feasible recovery choices.

## Features

- Tkinter desktop interface with friendly input validation
- Missed-connection detection using real `datetime.time` objects (not string comparison)
- CSV route loading with Pandas and basic malformed-row handling
- Direct future-service filtering: departed routes are never suggested
- Waiting time, travel time, cost, transfers, vacancies, and reliability calculation
- 0–100 recovery score, ranking, and readable explanation for every option
- Results table showing rank, route, transport, operator, timings, price, transfers, vacancies, and score
- Dynamic seat booking panel: booking a ticket decrements vacancies in real-time, persists updates to the route dataset, and ensures subsequent queries or passengers see the updated vacancy count
- Optional Matplotlib charts comparing scores, prices, and available vacancies
- Basic OOP: `Journey`, `Transport`, `Bus`, `Train`, and `RecoveryOption`

## Technology stack

Python, Tkinter, Pandas, NumPy, Matplotlib, and CSV. No database, payment system, or live transport API is used.

## Project structure

```
MissedBusRecovery/
├── main.py              # Tkinter user interface and application entry point
├── journey.py           # Journey model and safe time utilities
├── transport.py         # Transport, Bus, Train, RecoveryOption classes
├── data_loader.py       # CSV loading and validation with Pandas
├── validator.py         # User-input validation
├── recovery_engine.py   # Feasibility and route-search business logic
├── scoring.py           # Normalization, weights, score calculation, ranking
├── charts.py            # Optional Matplotlib comparison chart
├── data/routes.csv      # Synthetic academic transport data
├── requirements.txt
└── .gitignore
```

## Dataset

`data/routes.csv` is a small, realistic-looking **synthetic academic dataset**. It includes buses and trains among Kolhapur, Pune, Mumbai, Nashik, and Satara. The values, including reliability, are sample values and are not live data.

## How the algorithm works

1. Validate locations and parse all `HH:MM` times.
2. A connection is **missed** only when actual arrival is later than its scheduled departure. Equal times are treated as still possible, as documented project policy.
3. Filter CSV services matching the current location and destination, keeping only departures later than the current time.
4. Calculate each option's waiting and travel minutes.
5. Normalize lower-is-better travel time, fare, waiting time, and transfers to 0–100. When values are equal, each receives 100 to avoid division by zero. Reliability is already a 0–100 value.
6. Sort descending by score and assign ranks. This identifies the highest-scoring academic-model option, not a guaranteed best route.

## Scoring formula

```
Recovery Score = 0.35 × Time Score
               + 0.25 × Cost Score
               + 0.15 × Waiting Score
               + 0.15 × Transfer Score
               + 0.10 × Reliability Score
```

The configurable constants are in `scoring.py`. These are academic weights, not universal travel advice.

## Installation and run

From the project directory:

```bash
python -m pip install -r requirements.txt
python main.py
```

Tkinter ships with most standard Python installations. On a Linux distribution where it is absent, install the OS package for Tkinter (commonly `python3-tk`).

## Demonstration scenario

Use the values already prefilled in the app:

| Field | Value |
|---|---|
| Current Location | Pune |
| Destination | Mumbai |
| Current Time | 13:15 |
| Original Connection Departure | 12:30 |
| Actual Arrival Time | 13:00 |

The app reports **MISSED** and ranks available Pune-to-Mumbai alternatives including a 13:45 bus, 14:20 train, and 14:30 bus.

## Testing covered

The core logic has checks for: missed and still-possible connections, multiple alternatives, no future alternatives, empty location, invalid time, scoring bounds, rank assignment, and filtering of departed services. The GUI additionally reports malformed input, missing/unreadable CSV data, and no feasible route in user-friendly messages.

## Future scope

Possible extensions include live transport data, cancellations, GPS, notifications, payment integration, historical delay analytics, and graph-based multi-leg recovery. They are intentionally outside this CSV-only academic MVP.

## Short viva explanation

The project separates the interface from the algorithm. Tkinter gets validated user input; Pandas reads and filters the CSV; Python classes represent the journey and transport objects; the recovery engine calculates durations; NumPy-backed normalization makes unlike values comparable; and the scoring module ranks the choices. `Bus` and `Train` demonstrate simple inheritance from `Transport`.
