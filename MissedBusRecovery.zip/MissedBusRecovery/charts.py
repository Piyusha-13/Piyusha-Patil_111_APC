"""Small optional Matplotlib chart for the displayed options."""
import matplotlib.pyplot as plt


def show_analytics(options):
    if not options:
        return
    labels = [f"#{item.rank} {item.transport.route_id}" for item in options]
    scores = [item.score for item in options]
    costs = [item.transport.price for item in options]
    vacancies = [item.transport.vacancies for item in options]
    figure, axes = plt.subplots(1, 3, figsize=(13, 4.5))
    axes[0].bar(labels, scores, color="#277da1")
    axes[0].set_title("Recovery Score Comparison")
    axes[0].set_ylabel("Score (0-100)")
    axes[0].tick_params(axis="x", rotation=35)
    axes[1].bar(labels, costs, color="#f4a261")
    axes[1].set_title("Fare Comparison")
    axes[1].set_ylabel("Price (Rs.)")
    axes[1].tick_params(axis="x", rotation=35)
    axes[2].bar(labels, vacancies, color="#2a9d8f")
    axes[2].set_title("Available Vacancies")
    axes[2].set_ylabel("Vacancies (Seats)")
    axes[2].tick_params(axis="x", rotation=35)
    figure.tight_layout()
    plt.show()
