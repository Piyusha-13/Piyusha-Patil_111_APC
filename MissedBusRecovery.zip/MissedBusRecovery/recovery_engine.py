"""Core missed-connection and alternative-search logic, independent of Tkinter."""
from journey import minutes_between, format_duration
from transport import Bus, Train, Transport, RecoveryOption
from scoring import calculate_scores


def check_connection_feasibility(journey):
    """Return true when missed. Arrival exactly at departure remains possible."""
    return journey.connection_is_missed()


def _make_transport(row):
    common = dict(
        route_id=row.route_id, operator=row.operator, transport_type=row.transport_type,
        source=row.source, destination=row.destination,
        departure=row.departure_time.time(), arrival=row.arrival_time.time(),
        price=float(row.price), transfers=int(row.transfers), reliability=float(row.reliability),
        vacancies=int(getattr(row, "vacancies", 7)),
    )
    if str(row.transport_type).casefold() == "bus":
        return Bus(**common)
    if str(row.transport_type).casefold() == "train":
        return Train(**common)
    return Transport(**common)


def _explanation(option):
    service = option.transport
    strengths = []
    if service.transfers == 0:
        strengths.append("zero transfers")
    if service.reliability >= 85:
        strengths.append("high reliability")
    if option.waiting_time <= 60:
        strengths.append("a short wait")
    if option.travel_time <= 240:
        strengths.append("a short journey")
    if service.vacancies > 0:
        strengths.append(f"{service.vacancies} vacancies available")
    reason = ", ".join(strengths) if strengths else "its balanced time, cost and reliability factors"
    return (f"Waiting: {format_duration(option.waiting_time)} | Travel: {format_duration(option.travel_time)} | "
            f"Cost: Rs. {service.price:.0f} | Transfers: {service.transfers} | "
            f"Vacancies: {service.vacancies} | "
            f"Reliability: {service.reliability:.0f}%. Score is supported by {reason}.")


def find_recovery_options(journey, routes):
    """Find direct, future services and return them ranked by recovery score."""
    matches = routes[
        (routes["source"].str.casefold() == journey.current_location.casefold())
        & (routes["destination"].str.casefold() == journey.destination.casefold())
        & (routes["departure_time"].dt.time > journey.current_time)
        & (routes["vacancies"] > 0)
    ].sort_values("departure_time")
    options = []
    for row in matches.itertuples(index=False):
        transport = _make_transport(row)
        option = RecoveryOption(
            transport=transport,
            waiting_time=minutes_between(journey.current_time, transport.departure),
            travel_time=minutes_between(transport.departure, transport.arrival),
        )
        options.append(option)
    options = calculate_scores(options)
    for option in options:
        option.explanation = _explanation(option)
    return options
