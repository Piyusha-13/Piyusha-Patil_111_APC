"""Input validation kept separate from the GUI."""
from journey import parse_time
import re


def validate_journey_input(current_location, destination, current_time,
                           scheduled_connection, actual_arrival,
                           allowed_locations=None, allowed_pairs=None):
    if not current_location or not current_location.strip():
        raise ValueError("Please enter current location.")
    if not destination or not destination.strip():
        raise ValueError("Please enter destination.")
    if not re.fullmatch(r"[A-Za-z][A-Za-z\s]{1,49}", current_location.strip()):
        raise ValueError("Current location must contain letters only.")
    if not re.fullmatch(r"[A-Za-z][A-Za-z\s]{1,49}", destination.strip()):
        raise ValueError("Destination must contain letters only.")
    if current_location.strip().casefold() == destination.strip().casefold():
        raise ValueError("Current location and destination must be different.")
    if allowed_locations is not None:
        allowed = {location.casefold() for location in allowed_locations}
        if current_location.strip().casefold() not in allowed:
            raise ValueError("Please select a current location from the available route locations.")
        if destination.strip().casefold() not in allowed:
            raise ValueError("Please select a destination from the available route locations.")
    if allowed_pairs is not None:
        source = current_location.strip().casefold()
        target = destination.strip().casefold()
        valid_destinations = {
            destination_name.casefold()
            for destination_name in allowed_pairs.get(
                next((name for name in allowed_pairs if name.casefold() == source), ""),
                [],
            )
        }
        if source not in {name.casefold() for name in allowed_pairs} or target not in valid_destinations:
            raise ValueError("This route is not available in the CSV. Please select an exact route pair.")
    return (
        current_location.strip().title(),
        destination.strip().title(),
        parse_time(current_time),
        parse_time(scheduled_connection),
        parse_time(actual_arrival),
    )


def validate_mobile_number(mobile_number):
    """Validate and normalize an Indian 10-digit mobile number."""
    mobile = mobile_number.strip()
    if len(mobile) != 10 or not mobile.isdigit():
        raise ValueError("Please enter a valid 10-digit mobile number.")
    if mobile[0] not in "6789":
        raise ValueError("Mobile number must start with 6, 7, 8, or 9.")
    if len(set(mobile)) == 1:
        raise ValueError("Please enter a valid mobile number; it cannot contain only the same digit.")
    return mobile


def validate_passenger_name(passenger_name):
    """Validate a passenger name for the booking form."""
    name = " ".join(passenger_name.strip().split())
    if len(name) < 2 or len(name) > 50:
        raise ValueError("Passenger name must be between 2 and 50 characters.")
    if not re.fullmatch(r"[A-Za-z][A-Za-z ]*", name):
        raise ValueError("Passenger name must contain letters and spaces only.")
    return name


def validate_seat_preference(preference):
    allowed = ("Window", "Aisle", "No preference")
    if preference not in allowed:
        raise ValueError("Please select a valid seat preference.")
    return preference
