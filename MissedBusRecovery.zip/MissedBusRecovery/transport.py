"""Simple transport classes used by the recovery engine."""
from dataclasses import dataclass
from datetime import time


@dataclass
class Transport:
    route_id: str
    operator: str
    transport_type: str
    source: str
    destination: str
    departure: time
    arrival: time
    price: float
    transfers: int
    reliability: float
    vacancies: int = 7


class Bus(Transport):
    """A bus is a transport service."""


class Train(Transport):
    """A train is a transport service."""


@dataclass
class RecoveryOption:
    transport: Transport
    waiting_time: int
    travel_time: int
    score: float = 0.0
    rank: int = 0
    explanation: str = ""
