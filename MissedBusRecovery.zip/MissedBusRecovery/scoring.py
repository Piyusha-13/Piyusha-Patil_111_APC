"""Transparent 0-100 scoring functions for academic use."""
import numpy as np

TIME_WEIGHT = 0.35
COST_WEIGHT = 0.25
WAITING_WEIGHT = 0.15
TRANSFER_WEIGHT = 0.15
RELIABILITY_WEIGHT = 0.10


def lower_is_better(values):
    """Normalize values so the lowest becomes 100 and the highest becomes 0."""
    values = np.asarray(values, dtype=float)
    low, high = values.min(), values.max()
    if np.isclose(low, high):
        return np.full(len(values), 100.0)
    return 100 * (high - values) / (high - low)


def calculate_scores(options):
    """Set weighted recovery scores and ranks on RecoveryOption objects."""
    if not options:
        return []
    travel_scores = lower_is_better([item.travel_time for item in options])
    cost_scores = lower_is_better([item.transport.price for item in options])
    waiting_scores = lower_is_better([item.waiting_time for item in options])
    transfer_scores = lower_is_better([item.transport.transfers for item in options])
    reliability_scores = np.asarray([item.transport.reliability for item in options], dtype=float)
    for index, option in enumerate(options):
        option.score = round(
            TIME_WEIGHT * travel_scores[index]
            + COST_WEIGHT * cost_scores[index]
            + WAITING_WEIGHT * waiting_scores[index]
            + TRANSFER_WEIGHT * transfer_scores[index]
            + RELIABILITY_WEIGHT * reliability_scores[index], 2)
    options.sort(key=lambda item: (-item.score, item.transport.departure, item.transport.route_id))
    for rank, option in enumerate(options, start=1):
        option.rank = rank
    return options
