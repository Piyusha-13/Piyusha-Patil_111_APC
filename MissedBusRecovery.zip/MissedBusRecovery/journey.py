"""Journey model and reusable time helpers."""
from dataclasses import dataclass
from datetime import datetime, time
import re


def parse_time(value: str) -> time:
    """Parse a 24-hour HH:MM value, raising ValueError when it is invalid."""
    try:
        if not isinstance(value, str) or not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", value.strip()):
            raise ValueError
        return datetime.strptime(value.strip(), "%H:%M").time()
    except (ValueError, AttributeError) as error:
        raise ValueError("Invalid time. Please use HH:MM format (for example, 13:15).") from error


def minutes_between(start: time, end: time) -> int:
    """Return elapsed minutes. An end before start is treated as next day."""
    start_minutes = start.hour * 60 + start.minute
    end_minutes = end.hour * 60 + end.minute
    difference = end_minutes - start_minutes
    return difference if difference >= 0 else difference + 24 * 60


def format_duration(minutes: int) -> str:
    hours, remaining_minutes = divmod(int(minutes), 60)
    return f"{hours}h {remaining_minutes:02d}m" if hours else f"{remaining_minutes} min"


@dataclass
class Journey:
    current_location: str
    destination: str
    current_time: time
    scheduled_connection: time
    actual_arrival: time

    def connection_is_missed(self) -> bool:
        """Equal arrival/departure is allowed; only later arrival means missed."""
        return self.actual_arrival > self.scheduled_connection
