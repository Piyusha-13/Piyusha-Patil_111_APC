"""Tkinter entry point for the Missed Bus Connection Recovery System."""
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from data_loader import load_routes, update_route_vacancies, get_route_locations, get_route_pairs
from journey import Journey, format_duration
from validator import (
    validate_journey_input,
    validate_mobile_number,
    validate_passenger_name,
    validate_seat_preference,
)
from recovery_engine import check_connection_feasibility, find_recovery_options, _explanation
from charts import show_analytics


class RecoveryApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Missed Bus Connection Recovery System")
        self.geometry("1200x850")
        self.minsize(1000, 760)
        self.options = []
        self.bookings = []
        self._create_styles()
        self._build_interface()

    def _create_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"), foreground="#17324d")
        style.configure("Subtitle.TLabel", font=("Segoe UI", 10), foreground="#526777")
        style.configure("Status.TLabel", font=("Segoe UI", 11, "bold"))
        style.configure("Recommendation.TLabel", font=("Segoe UI", 10), foreground="#17324d")
        style.configure("Treeview", rowheight=28, font=("Segoe UI", 9))
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

    def _build_interface(self):
        outer = ttk.Frame(self, padding=16)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Missed Bus Connection Recovery System", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="CSV-based academic decision support — not a booking system or live transport service.",
                  style="Subtitle.TLabel").pack(anchor="w", pady=(2, 14))

        form = ttk.LabelFrame(outer, text="Journey information", padding=12)
        form.pack(fill="x")
        self.fields = {}
        labels = [
            ("Current Location", "Pune"), ("Destination", "Mumbai"),
            ("Current Time (HH:MM)", "13:15"),
            ("Original Connection Departure (HH:MM)", "12:30"),
            ("Actual Arrival Time (HH:MM)", "13:00"),
        ]
        route_pairs = get_route_pairs()
        route_sources = list(route_pairs.keys())
        for column, (label, default) in enumerate(labels):
            ttk.Label(form, text=label).grid(row=0, column=column, padx=5, sticky="w")
            if label in ("Current Location", "Destination"):
                values = (
                    route_sources
                    if label == "Current Location"
                    else route_pairs.get("Pune", [])
                )
                entry = ttk.Combobox(
                    form,
                    values=values,
                    state="readonly",
                    width=21,
                )
                entry.set(default if default in values else "")
            else:
                entry = ttk.Entry(form, width=21)
                entry.insert(0, default)
            entry.grid(row=1, column=column, padx=5, pady=(3, 8), sticky="ew")
            self.fields[label] = entry
            form.columnconfigure(column, weight=1)
        self.route_pairs = route_pairs
        self.fields["Current Location"].bind("<<ComboboxSelected>>", self.update_destination_options)
        ttk.Button(form, text="Check & Find Recovery Options", command=self.check_journey).grid(
            row=2, column=0, columnspan=3, padx=5, pady=(4, 0), sticky="w")
        ttk.Button(form, text="View Analytics", command=self.view_analytics).grid(
            row=2, column=3, columnspan=2, padx=5, pady=(4, 0), sticky="w")
        ttk.Button(form, text="About Project", command=self.show_about).grid(
            row=2, column=4, padx=5, pady=(4, 0), sticky="e")
        
        self.status = ttk.Label(outer, text="Enter journey details, then check the connection.", style="Status.TLabel")
        self.status.pack(anchor="w", pady=12)
        table_frame = ttk.Frame(outer)
        table_frame.pack(fill="both", expand=True)
        columns = ("rank", "route", "transport", "operator", "departure", "arrival", "waiting", "travel", "price", "transfers", "vacancies", "score")
        self.table = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        headings = ("Rank", "Route ID", "Transport", "Operator", "Departure", "Arrival", "Waiting", "Travel Time", "Price", "Transfers", "Vacancies", "Score")
        widths = (50, 70, 80, 140, 70, 70, 80, 85, 70, 65, 75, 65)
        for key, heading, width in zip(columns, headings, widths):
            self.table.heading(key, text=heading)
            self.table.column(key, width=width, anchor="center")
        self.table.column("operator", anchor="w")
        self.table.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        scrollbar.pack(side="right", fill="y")
        self.table.configure(yscrollcommand=scrollbar.set)
        self.table.bind("<<TreeviewSelect>>", self.show_selected_explanation)

        booking = ttk.LabelFrame(outer, text="Book Selected Bus / Train", padding=10)
        booking.pack(fill="x", pady=(12, 0))
        ttk.Label(booking, text="Passenger Name").grid(row=0, column=0, padx=5, sticky="w")
        self.passenger_name = ttk.Entry(booking, width=28)
        self.passenger_name.grid(row=1, column=0, padx=5, pady=(3, 0), sticky="ew")
        ttk.Label(booking, text="Mobile Number").grid(row=0, column=1, padx=5, sticky="w")
        self.mobile_number = ttk.Entry(booking, width=20)
        self.mobile_number.grid(row=1, column=1, padx=5, pady=(3, 0), sticky="ew")
        ttk.Label(booking, text="Seat Preference").grid(row=0, column=2, padx=5, sticky="w")
        self.seat_preference = ttk.Combobox(
            booking, values=("Window", "Aisle", "No preference"), state="readonly", width=18)
        self.seat_preference.set("No preference")
        self.seat_preference.grid(row=1, column=2, padx=5, pady=(3, 0), sticky="ew")
        ttk.Button(booking, text="Book Selected Service", command=self.book_selected_service).grid(
            row=1, column=3, padx=12, pady=(3, 0), sticky="ew")
        self.booking_status = ttk.Label(
            booking, text="Select a route from the table, then enter passenger details.")
        self.booking_status.grid(row=2, column=0, columnspan=4, padx=5, pady=(8, 0), sticky="w")
        for column in range(4):
            booking.columnconfigure(column, weight=1 if column < 3 else 0)

        recommendation = ttk.LabelFrame(outer, text="Highest Scoring Recovery Option", padding=10)
        recommendation.pack(fill="x", pady=(12, 0))
        self.recommendation_output = tk.Text(
            recommendation,
            height=3,
            width=100,
            font=("Segoe UI", 10),
            foreground="#17324d",
            background="#ffffff",
            relief="flat",
            wrap="word",
            padx=8,
            pady=6,
            takefocus=False,
        )
        self.recommendation_output.pack(fill="x", expand=True)
        self.recommendation_output.insert("1.0", "Results will appear here after a missed connection is checked.")
        self.recommendation_output.configure(state="disabled")

    def _update_recommendation(self, message):
        self.recommendation_output.configure(state="normal")
        self.recommendation_output.delete("1.0", "end")
        self.recommendation_output.insert("1.0", message)
        self.recommendation_output.configure(state="disabled")

    def _clear_results(self):
        for row in self.table.get_children():
            self.table.delete(row)
        self.options = []
        self._update_recommendation("Results will appear here after a missed connection is checked.")
        self.booking_status.configure(text="Select a route from the table, then enter passenger details.")

    def update_destination_options(self, _event=None):
        source = self.fields["Current Location"].get().strip()
        destinations = self.route_pairs.get(
            next((name for name in self.route_pairs if name.casefold() == source.casefold()), ""),
            [],
        )
        destination_field = self.fields["Destination"]
        destination_field.configure(values=destinations)
        current_destination = destination_field.get()
        if current_destination not in destinations:
            destination_field.set(destinations[0] if destinations else "")

    def check_journey(self):
        self._clear_results()
        try:
            location, destination, now, scheduled, actual = validate_journey_input(
                self.fields["Current Location"].get(), self.fields["Destination"].get(),
                self.fields["Current Time (HH:MM)"].get(),
                self.fields["Original Connection Departure (HH:MM)"].get(),
                self.fields["Actual Arrival Time (HH:MM)"].get(),
                get_route_locations(),
                get_route_pairs())
            journey = Journey(location, destination, now, scheduled, actual)
            if not check_connection_feasibility(journey):
                self.status.configure(text="Original Connection: STILL POSSIBLE — arrival at the same time is treated as possible.", foreground="#237a3b")
                self._update_recommendation("Your original connection has not been missed, so recovery alternatives are not required.")
                return
            self.status.configure(text="Original Connection: MISSED — searching future direct services from the sample CSV.", foreground="#b54708")
            self.options = find_recovery_options(journey, load_routes())
            if not self.options:
                self.status.configure(text="Original Connection: MISSED — No feasible recovery options found for the current journey.", foreground="#b54708")
                self._update_recommendation("No matching future direct service was found. Try another route or time.")
                return
            for option in self.options:
                service = option.transport
                self.table.insert("", "end", iid=str(option.rank), values=(
                    option.rank, service.route_id, service.transport_type, service.operator,
                    service.departure.strftime("%H:%M"), service.arrival.strftime("%H:%M"),
                    format_duration(option.waiting_time), format_duration(option.travel_time),
                    f"Rs. {service.price:.0f}", service.transfers, service.vacancies, f"{option.score:.2f}"))
            best = self.options[0]
            self._update_recommendation(
                f"Highest scoring option: {best.transport.transport_type} {best.transport.route_id} by {best.transport.operator} — "
                f"Score {best.score:.2f}/100 | Vacancies: {best.transport.vacancies}.\n{best.explanation}")
            self.table.selection_set("1")
        except (ValueError, FileNotFoundError) as error:
            self.status.configure(text="Please correct the input and try again.", foreground="#b42318")
            messagebox.showerror("Cannot check journey", str(error))
        except Exception as error:
            self.status.configure(text="The route data could not be processed.", foreground="#b42318")
            messagebox.showerror("Unexpected error", f"The application could not process the route data.\n{error}")

    def show_selected_explanation(self, _event=None):
        selected = self.table.selection()
        if selected and self.options:
            rank = int(selected[0])
            option = next((item for item in self.options if item.rank == rank), None)
            if option:
                service = option.transport
                if option.rank == 1:
                    self._update_recommendation(
                        f"Highest scoring option: {service.transport_type} {service.route_id} by {service.operator} — "
                        f"Score {option.score:.2f}/100 | Vacancies: {service.vacancies}.\n{option.explanation}")
                else:
                    self._update_recommendation(
                        f"Selected option #{option.rank}: {service.transport_type} {service.route_id} by {service.operator} — "
                        f"Score {option.score:.2f}/100 | Vacancies: {service.vacancies}.\n{option.explanation}")
                self.booking_status.configure(
                    text=f"Selected: {service.transport_type} {service.route_id} by {service.operator} ({service.vacancies} vacancies available).")

    def book_selected_service(self):
        """Create a confirmation for the selected service and decrement vacancies."""
        selected = self.table.selection()
        passenger = self.passenger_name.get().strip()
        mobile = self.mobile_number.get().strip()
        if not selected:
            messagebox.showwarning("Select a service", "Please select a bus or train from the recovery options table.")
            return
        try:
            passenger = validate_passenger_name(passenger)
        except ValueError as error:
            messagebox.showwarning("Invalid passenger name", str(error))
            return
        try:
            mobile = validate_mobile_number(mobile)
        except ValueError as error:
            messagebox.showwarning("Invalid mobile number", str(error))
            return
        try:
            seat_preference = validate_seat_preference(self.seat_preference.get())
        except ValueError as error:
            messagebox.showwarning("Invalid seat preference", str(error))
            return
        rank = int(selected[0])
        option = next((item for item in self.options if item.rank == rank), None)
        if option is None:
            messagebox.showerror("Booking unavailable", "The selected recovery option is no longer available.")
            return

        service = option.transport
        if service.vacancies <= 0:
            messagebox.showwarning(
                "No Vacancies Available",
                f"Sorry, {service.transport_type} {service.route_id} has 0 vacancies available.\n"
                "Please select another bus or train option.")
            return

        # Deduct 1 seat/vacancy and persist to routes.csv
        service.vacancies -= 1
        update_route_vacancies(service.route_id, service.vacancies)

        # Update the Treeview row immediately to reflect the new vacancy count
        self.table.item(str(option.rank), values=(
            option.rank, service.route_id, service.transport_type, service.operator,
            service.departure.strftime("%H:%M"), service.arrival.strftime("%H:%M"),
            format_duration(option.waiting_time), format_duration(option.travel_time),
            f"Rs. {service.price:.0f}", service.transfers, service.vacancies, f"{option.score:.2f}"))

        booking_id = f"MBR{datetime.now():%Y%m%d%H%M%S}{len(self.bookings) + 1:02d}"
        booking = {
            "booking_id": booking_id, "passenger": passenger, "mobile": mobile,
            "seat_preference": seat_preference, "option": option,
        }
        self.bookings.append(booking)

        # Update explanations and status labels
        option.explanation = _explanation(option)
        self.show_selected_explanation()
        self.booking_status.configure(
            text=f"Booking confirmed: {booking_id} for {passenger} on {service.route_id}. ({service.vacancies} vacancies remaining)")

        messagebox.showinfo(
            "Booking Confirmed",
            f"Booking ID: {booking_id}\n\n"
            f"Passenger: {passenger}\nService: {service.transport_type} {service.route_id} ({service.operator})\n"
            f"Route: {service.source} to {service.destination}\n"
            f"Departure: {service.departure:%H:%M} | Arrival: {service.arrival:%H:%M}\n"
            f"Fare: Rs. {service.price:.0f}\nSeat preference: {booking['seat_preference']}\n"
            f"Vacancies remaining: {service.vacancies}\n\n"
            "This is a local academic-project booking confirmation only. No payment or real reservation was made.")

        # Clear passenger inputs for the next booking
        self.passenger_name.delete(0, "end")
        self.mobile_number.delete(0, "end")

    def view_analytics(self):
        if not self.options:
            messagebox.showinfo("Analytics", "Find recovery options first to view the comparison chart.")
            return
        try:
            show_analytics(self.options)
        except ImportError:
            messagebox.showerror("Analytics unavailable", "Matplotlib is not installed. Run: pip install -r requirements.txt")

    def show_about(self):
        messagebox.showinfo(
            "About Project",
            "Missed Bus Connection Recovery System\n\n"
            "Purpose: find and rank feasible alternatives after a missed connection.\n\n"
            "Technology: Python, Tkinter, Pandas, NumPy, Matplotlib and CSV.\n"
            "Data: synthetic academic transportation dataset.\n\n"
            "Local simulated booking is available for selected sample services.\n"
            "No database, live API, payment, or real reservation is used.")


if __name__ == "__main__":
    RecoveryApp().mainloop()
