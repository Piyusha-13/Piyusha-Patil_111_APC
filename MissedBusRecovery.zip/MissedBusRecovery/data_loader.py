"""CSV loading, dataset validation, and vacancy persistence."""
from pathlib import Path
import pandas as pd

REQUIRED_COLUMNS = [
    "route_id", "operator", "transport_type", "source", "destination",
    "departure", "arrival", "price", "transfers", "reliability", "vacancies"
]

def load_routes():
    """Load the bundled synthetic route data and discard malformed rows."""
    csv_path = Path(__file__).resolve().parent / "data" / "routes.csv"
    if not csv_path.exists():
        raise FileNotFoundError("Route dataset could not be found.")
    try:
        routes = pd.read_csv(csv_path)
    except (OSError, pd.errors.ParserError) as error:
        raise ValueError("Route dataset could not be read.") from error

    # Fallback default if legacy CSV without vacancies is loaded
    if "vacancies" not in routes.columns:
        routes["vacancies"] = 7

    missing = set(REQUIRED_COLUMNS) - set(routes.columns)
    if missing:
        raise ValueError("Route dataset is missing required columns: " + ", ".join(sorted(missing)))

    routes = routes[REQUIRED_COLUMNS].copy()
    for column in ("price", "transfers", "reliability", "vacancies"):
        routes[column] = pd.to_numeric(routes[column], errors="coerce")
    routes["departure_time"] = pd.to_datetime(routes["departure"], format="%H:%M", errors="coerce")
    routes["arrival_time"] = pd.to_datetime(routes["arrival"], format="%H:%M", errors="coerce")
    routes = routes.dropna().copy()
    routes = routes[(routes["price"] >= 0) & (routes["transfers"] >= 0)]
    routes["reliability"] = routes["reliability"].clip(0, 100)
    routes["vacancies"] = routes["vacancies"].clip(lower=0).astype(int)
    return routes.reset_index(drop=True)


def get_route_locations():
    """Return unique source and destination names from the route dataset."""
    routes = load_routes()
    locations = set(routes["source"].dropna().astype(str))
    locations.update(routes["destination"].dropna().astype(str))
    return sorted(locations, key=str.casefold)


def get_route_pairs():
    """Return exact source-to-destination pairs available in the route CSV."""
    routes = load_routes()
    pairs = {}
    for source, destination in routes[["source", "destination"]].dropna().itertuples(index=False, name=None):
        source = str(source).strip()
        destination = str(destination).strip()
        if source and destination:
            pairs.setdefault(source, set()).add(destination)
    return {
        source: sorted(destinations, key=str.casefold)
        for source, destinations in sorted(pairs.items(), key=lambda item: item[0].casefold())
    }


def update_route_vacancies(route_id: str, vacancies: int) -> bool:
    """Persist updated vacancy count for a route back to data/routes.csv."""
    csv_path = Path(__file__).resolve().parent / "data" / "routes.csv"
    if not csv_path.exists():
        return False
    try:
        routes = pd.read_csv(csv_path)
        if "vacancies" not in routes.columns:
            routes["vacancies"] = 7
        mask = routes["route_id"].astype(str).str.strip().str.casefold() == str(route_id).strip().casefold()
        if not mask.any():
            return False
        routes.loc[mask, "vacancies"] = max(0, int(vacancies))
        routes.to_csv(csv_path, index=False)
        return True
    except Exception:
        return False
